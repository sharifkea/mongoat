<?php
class mdb_mysqli {
    public $host;
    public $user;
    public $pass;
    public $sqldb;
    public $insert_id;
    public $connect_error;
    public $table;

    function __construct($host,$user,$pass,$sqldb) {
        //require __DIR__ . '/mongo.php';
        $this->host = $host; 
        $this->user = $user;
        $this->pass = $pass; 
        $this->sqldb = $sqldb;
        $this->insert_id = 0;
        $this->connect_error = True;
        $key=array('dbInfo'=>$sqldb,'host'=>$host,'user'=>$user,'password'=>$pass);
        //var_dump($key);
        //require_once __DIR__ . '/stmmongo.php';
        //$db = $client->$mdb->$coll;
        $document = $this->find_one($key); 
        //var_dump($document); 
        if(isset($document)){
            $this->connect_error = False;
            //echo 'table is  there.';
            if($document['tableNo']!=0){
                $this->table=$document['tableNames'];
            }
        }
    }
    function query($data){
        //foreach($this->table as $doc)
        //echo "\r\n".$data."\r\n";
        $fstPiec = strtok($data, " ");
        if(!strcasecmp($fstPiec,'SELECT')){$ret=$this->stmSelect($data);if(!$ret)$ret=false;}
        else if(!strcasecmp($fstPiec,'INSERT')){{$ret=$this->stmInsert($data);}}
        else if(!strcasecmp($fstPiec,'DELETE')){{$ret=$this->stmDelete($data);}}
        else if(!strcasecmp($fstPiec,'UPDATE')){{$ret=$this->stmUpdate($data);}}
        return $ret;
    }

    function close(){
    }
    function cleanData($data){
        $data = str_replace([",","(",")","(","'",'"',"="], ' ', $data);
        if(substr($data, -1)==';')$data = substr($data,0,-1);
        $data = preg_replace('/\s+/', ' ', $data);
        if(substr($data, -1)==' ')$data = substr($data,0,-1);
        return $data;
    }
    function stmSelect($data){
        if(stripos($data, 'JOIN') !== false) return $this->stmJoin($data);
        $data=$this->cleanData($data); 
        $pieces = explode(' ',$data);
        $piecesCount = count($pieces);
        $all=0;
        $c=0;
        $t=0;
        $w=0;
        for($i=1;$i<$piecesCount;$i++){
            if($c==0){
                if(!strcasecmp($pieces[$i],'FROM')){
                    if($all==0)$colCnt=$i-1;
                    $c=1;
                }
                else if ($pieces[$i]=='*') $all=1;                   
                else{
                    $col[$i-1]=$pieces[$i];
                }
            }else{
                if($t==0){
                    $tab=$pieces[$i];
                    $t=1;
                }else{
                    if(isset($pieces[$i])&&isset($pieces[$i+1])&&isset($pieces[$i+2])&&!strcasecmp($pieces[$i],'WHERE')){
                        $wTab=$pieces[$i+1];
                        $wValue=$pieces[$i+2];
                        $i==$piecesCount;
                    }
                }
            }
        }
        $out="Get ";
        if($all==1)$out .= "All From Table:".$tab;
        else{
            for($i=0;$i<$colCnt;$i++){
                $out .="Colunm:".$col[$i].",";
            }
            $out = substr_replace($out ,"", -1);
            $out .= " From Table:".$tab;
        }if(isset($wTab)&&isset($wValue)){$out .=" Where Column:".$wTab." And The Value:".$wValue;
            $key=array("tableName"=>$tab,$wTab=>$wValue);
        }else $key=array("tableName"=>$tab);
        echo $out;
        $rows=$this->all_query($key);
        $tbKey=array("tableInfo"=>$tab);
        $tbInf=$this->find_one($tbKey);
        if(!isset($colCnt)||$colCnt==0){         
            //var_dump($tbInf);
            $col=$tbInf['columnNames'];
            $colCnt=$tbInf['columnNo'];
        }$p=0;
        $final=array('current_field' => 0,
                    'field_count' => $colCnt,
                    'lengths' => null,
                    'num_rows' => $tbInf['rowNo'],
                    'type' => 0);
        foreach($rows as $row){
            $row = json_decode(json_encode($row), true);
            for($i=0;$i<$colCnt;$i++){
                $newArray[$col[$i]]=$row[$col[$i]];
            }
            array_push($final, $newArray);
        }
        $object = new stdClass();
        foreach ($final as $key => $value)
        {
            $object->$key = $value;
        }
        return $object;   
    }

    function stmInsert($data){
        $data=$this->cleanData($data); 
        $pieces = explode(' ',$data);
        $piecesCount = count($pieces);
        $all=0;
        $c=0;
        $colCnt=0;
        //var_dump($pieces);
        $newData['tableName']=$pieces[2];
        if(!strcasecmp($pieces[4],'VALUE')){$colCnt=1;$newData[$pieces[3]]=$pieces[5];}
        else{$v=round((($piecesCount-3)/ 2)+2);
            if(!strcasecmp($pieces[$v],'VALUES')){
                for($i=3;$i<$v;$i++){
                    //$col[$colCnt]=$pieces[$i];
                    //$val[$colCnt]=$pieces[$v+1+$colCnt];
                    $newData[$pieces[$i]]=$pieces[$v+1+$colCnt];
                    $colCnt++;
                }
            }
        }
        $key=array('tableInfo'=>$newData['tableName']);
        $tbif=$this->find_one($key);
//var_dump ($tbif);
        if(isset($tbif['ai'])&&!isset($newData[$tbif['pk']])){$newData[$tbif['pk']]=$tbif['lastId']+1;
        }
        elseif(!isset($tbif['ai'])&&!isset($newData[$tbif['pk']]))$c=5;
        if($tbif['columnNo']!=count($newData)){
            foreach($tbif['columnNames'] as $index => $value){
                if($tbif['nl'][$index]==1 && !isset($newData[$value]))$c=6;
            }
        }
//var_dump($newData);
        if($c==0) $c=$this->inTbRow($newData);
        if($c==0) return true;
        else return false;
    }

    function stmDelete($data){
        $data=$this->cleanData($data); 
        $pieces = explode(' ',$data);
        $piecesCount = count($pieces);
//var_dump($pieces,$piecesCount);
        $newData['tableName']=$pieces[2];
        if($piecesCount==6){
            $wTab=$pieces[4];
            $wValue=$pieces[5];
        }
        
        $key=array('tableInfo'=>$newData['tableName']);
        $tbif=$this->find_one($key);
        $tbif = json_decode(json_encode($tbif), true);
        
        $pkInd=$this->strInArray($tbif['columnNames'],$wTab);
//var_dump($tbif,$wValue,$wTab);
        if($wTab!=$tbif['pk']){
            
//var_dump($pkInd);
            if($tbif['type'][$pkInd]=='integer')$wValue=intval($wValue);
            elseif($tbif['type'][$pkInd]=='boolean'){if($wValue=='true')$wValue=true;else $wValue=false;}
            $wKey=array($wTab=>$wValue,'tableName'=>$newData['tableName']);
            $rows=$this->all_query($wKey);
            $count=0;
            $retValue=1;
            $rowNo=$tbif['rowNo'];
            foreach($rows as $tbODt){
                $tbODt=json_decode(json_encode($tbODt), true);
//var_dump($tbODt);
                $retValue=0;
                unset($tbODt['_id']);
                if($this->fkRowIn($tbODt['tableName'],$tbODt[$tbif['pk']])==false) {
                    //$count++;
                    $rowKey=array('tableName'=>$tbODt['tableName'],$tbif['pk']=>$tbODt[$tbif['pk']]);
//var_dump($rowKey);
                    if($this->del($rowKey)){
                        $rowNo--;
                        $what=array('rowNo'=>$rowNo);
                        if($this->update($key,$what))$count++;
                    }   
                } else $retETR++;
            }if($count==0)return false;
        }
        else{
//var_dump($pkInd);
            if($tbif['type'][$pkInd]=='integer')$wValue=intval($wValue);
            $wKey=array($wTab=>$wValue,'tableName'=>$newData['tableName']);
            $row=$this->find_one($wKey);
            $count=0;
            $retValue=0;
            $row=json_decode(json_encode($row), true);
//var_dump($row);
            $retValue=0;
            unset($row['_id']);
            if($this->fkRowIn($row['tableName'],$row[$tbif['pk']])==false) {
                //$count++;
                $rowKey=array('tableName'=>$row['tableName'],$tbif['pk']=>$row[$tbif['pk']]);
                var_dump($rowKey);
                if($this->del($rowKey)){
                    $what=array('rowNo'=>$tbif['rowNo']-1);
                    if($this->update($key,$what))$count++;
                }  
            } else $retETR++;
            if($count==0) return false;
        }return true;
//var_dump($count,$retValue);   
    }
    

    function stmUpdate($data){
        $data=$this->cleanData($data);
//var_dump($data); 
        $pieces = explode(' ',$data);
        $piecesCount = count($pieces);
        //update scores SET game1=9, game2=6 where userID=1;
//var_dump($pieces);
        $newData['tableName']=$pieces[1];

        for($i=3;$i<$piecesCount;$i++){

            if(isset($pieces[$i])&&isset($pieces[$i+1])&&isset($pieces[$i+2])&&!strcasecmp($pieces[$i],'WHERE')){
                $wTab=$pieces[$i+1];
                $wValue=$pieces[$i+2];
                $i==$piecesCount;
            }
            else{
                $newData[$pieces[$i]]=$pieces[$i+1];$i++;
            }
        }
        $key=array('tableInfo'=>$newData['tableName']);
        $tbif=$this->find_one($key);
        $tbif = json_decode(json_encode($tbif), true);
//var_dump($tbif,$wValue,$wTab);
        if($wTab!=$tbif['pk']){
            $pkInd=$this->strInArray($tbif['columnNames'],$wTab);
//var_dump($pkInd);
            if($tbif['type'][$pkInd]=='integer')$wValue=intval($wValue);
            elseif($tbif['type'][$pkInd]=='boolean'){if($wValue=='true')$wValue=true;else $wValue=false;}

            $wKey=array($wTab=>$wValue,'tableName'=>$newData['tableName']);
            $rows=$this->all_query($wKey);
            $count=0;
            foreach($rows as $tbODt){
                $tbODt=json_decode(json_encode($tbODt), true);
//var_dump($tbODt);
                unset($tbODt['_id']);
                $count++;
                unset($agData);
                $agData=$newData;
                $agData[$wTab]=$wValue;
                foreach($tbif['columnNames'] as $index => $value){
                    if(!isset($agData[$value]))$agData[$value]=$tbODt[$value];
                }

                $pkInd=$this->strInArray($tbif['columnNames'],$tbif['pk']);
                //if($tbif['type'][$pkInd]=='integer')$tbODt[$tbif['pk']]=intval($wValue);
                $agData['pkType']=$tbif['type'][$pkInd];
                $agData['pkIndex']=$pkInd;
                $agData['oldpkv']=$tbODt[$tbif['pk']];

                foreach($tbif['columnNames'] as $index => $value){
                    if(!isset($agData[$value]))$agData[$value]=$tbODt[$value];
                }
//var_dump($agData);
                $retETR=$this->edTbRow($agData);
                if($retETR!=0)return false;
            }
        }
        else{
            $pkInd=$this->strInArray($tbif['columnNames'],$tbif['pk']);
            if($tbif['type'][$pkInd]=='integer')$wValue=intval($wValue);
            $newData['pkType']=$tbif['type'][$pkInd];
            $newData['pkIndex']=$pkInd;
            $newData['oldpkv']=$wValue;
            
            $wKey=array($wTab=>$wValue,'tableName'=>$newData['tableName']);
            $tbODt=$this->find_one($wKey);
            $tbODt = json_decode(json_encode($tbODt), true);
            foreach($tbif['columnNames'] as $index => $value){
                if(!isset($newData[$value]))$newData[$value]=$tbODt[$value];
            }

            $retETR=$this->edTbRow($newData);
            if($retETR!=0)return false;
        }
        return true;
    }

    function create($toDb){
        require __DIR__ . '/mongo.php';
        try{
            $db = $client->$mdb->$coll;// Mongodb 
            $insertOneResult = $db->insertOne($toDb);
            return true;
        }catch ( e ) {
            return false;
        }
    }
    
    function update($where,$what) {
        require __DIR__ . '/mongo.php';
        $collection = $client->selectCollection($mdb,$coll);
        if($collection->updateMany($where,['$set' => $what]))return true;
        else return false;
    }
    function find_one($key) {
        require __DIR__ . '/mongo.php';
        $db = $client->$mdb->$coll;
        return $db->findOne($key);
    }
    function del($which) {
        require __DIR__ . '/mongo.php';
        //require_once __DIR__ . '/mongo.php';
        $collection = $client->selectCollection($mdb,$coll);
        $r= $collection->deleteMany($which);
        return $r;    
    }
    function all_query($which) {
        require __DIR__ . '/mongo.php';
        $options= [];
        $query = new MongoDB\Driver\Query($which, $options);
        $manager = new MongoDB\Driver\Manager($murl);
        $rows = $manager->executeQuery($colldb, $query);
        //return $rows;
        return $rows->toArray();    
    }
    function strInArray($arr, $keyword) {
        foreach($arr as $index => $string) {
            if (strpos($string, $keyword) !== FALSE)
                return $index;//}
        }
    }
    function inTbRow($data){
        $tableName=$data['tableName'];
        $i=0;
        $key=array('tableInfo'=>$data['tableName']);
        $tbif=$this->find_one($key);
        //var_dump ($tbif);
        
        foreach($tbif['columnNames'] as $index => $value){
            if($tbif['nl'][$index]==0 && !isset($data[$value]))$data[$value]=NULL;
        }
    
        foreach($data as $index => $value){
            if($index!='tableName'){
                $cn=$this->strInArray($tbif['columnNames'],$index);
                if($tbif['type'][$cn]=='integer'){$data[$index]=intval($value);}
                if($tbif['type'][$cn]=='boolean'){if($data[$index]=='true')$data[$index]=true;else $data[$index]=false;}
                if(gettype($data[$index])!=$tbif['type'][$cn]) {$i=2;  return $i;}
            }
            unset($fk);
            if($tbif['fkNo']>0){
                $fk=$this->strInArray($tbif['fkName'],$index);
                if(isset($fk)){
                    $fkey=array('tableName'=>$tbif['fkTable'][$fk],$tbif['fkColumn'][$fk]=>$data[$index]);
                    //var_dump($fkey);
                    $ret=$this->find_one($mdbInfo,$fkey);
                    if(!isset($ret)) {$i=3;  return $i;}
                    //else echo //var_dump ($ret);
                }
            }
        }if(!isset($tbif['ai'])){$fpk=array('tableName'=>$tableName, $tbif['pk']=>$data[$tbif['pk']]);
            // //var_dump ($fpk);
             $pkRow=$this->find_one($fpk);
             if($pkRow){
                 $i=1;  return $i;
             }
         }
        if($this->create($data))
        {
            $what=array('lastId'=>$data[$tbif['pk']],'rowNo'=>$tbif['rowNo']+1);
            $upRet=$this->update($key,$what);
            $this->insert_id=$what['lastId'];
            return $i;
        }else {$i=4;  return $i;}
    }

    function edTbRow($data){
        if($data['pkType']=='integer')$data['oldpkv']=intval($data['oldpkv']);
        $oldpk=$data['oldpkv'];
        unset($data['oldpkv']);
        unset($data['pkType']);
        unset($data['pkIndex']);
        $i=0;
        $tableName=$data['tableName'];
        $key=array('tableInfo'=>$tableName);
        $tbif=$this->find_one($key);
        $tbif = json_decode(json_encode($tbif), true);
        $oldkey=array('tableName'=>$tableName, $tbif['pk']=>$oldpk);
        $oldrow=$this->find_one($oldkey);
        $dbKey=array('db'=>'RDMS');
        $dbif=$this->find_one($dbKey);
        $dbif = json_decode(json_encode($dbif), true);
        if($oldpk!=$data[$tbif['pk']]){$fpk=array('tableName'=>$tableName,$tbif['pk']=>$data[$tbif['pk']]);
            if($this->find_one($fpk)){
                $i=1; return $i;
            }
        }
        if($oldpk!=$data[$tbif['pk']]){
            if($this->fkRowIn($tableName,$oldpk)) {$i=2; return $i;} 
        }
        foreach($tbif['columnNames'] as $index => $value){
            if($tbif['nl'][$index]==0 && !isset($data[$value]))$data[$value]=NULL;
        }
        foreach($data as $index => $value){
            if($index!='tableName'){
                $cn=$this->strInArray($tbif['columnNames'],$index);
                if($tbif['type'][$cn]=='integer'){$data[$index]=intval($value);if($index==$tbif['pk'])$oldkey[$tbif['pk']]=intval($oldkey[$tbif['pk']]); }
                if($tbif['type'][$cn]=='boolean'){if($data[$index]=='true')$data[$index]=true;else $data[$index]=false;}
                if(gettype($data[$index])!=$tbif['type'][$cn]) {$i=3; return $i;}
            }
            unset($fk);
            if($tbif['fkNo']>0){
                $fk=$this->strInArray($tbif['fkName'],$index);
                if(isset($fk)){
                    $fkey=array('tableName'=>$tbif['fkTable'][$fk],$tbif['fkColumn'][$fk]=>$data[$index]);
                    ////var_dump($fkey);
                    $ret=$this->find_one($fkey);
                    if(!isset($ret)) { $i=4; return $i; }
                }
            }
        }
        if($this->del($oldkey)){
            if($this->create($data)) return $i;
        }else {$i=5; return $i;}
    }

    function fkRowIn($table,$fkV){
        $i=false;    
        $dbKey=array('db'=>'RDMS');
        $dbif=$this->find_one($dbKey);
        $dbif = json_decode(json_encode($dbif), true);
    
        foreach($dbif['tableNames'] as $index => $value){
            if ($value!=$table){
                $newKey=array('tableInfo'=>$value);
                $newtbif=$this->find_one($newKey);
                $newtbif = json_decode(json_encode($newtbif), true);
                if($newtbif['fkNo']>0){
                    foreach($newtbif['fkTable'] as $fktindex => $fktvalue){
                        if($fktvalue==$table){
                            $newfkC=$newtbif['fkName'][$fktindex];
                            $findFK=array('tableName'=>$value,$newfkC=>$fkV);
                            if($this->find_one($findFK))$i=true; 
                        }
                    }
                }
            }
        }
        return $i;
    }
    function stmJoin($data){
//var_dump($data);
        $newD=$data;
        $data = str_ireplace([" join "], ' JOIN ', $data);
        $data = str_ireplace(["select "], "SELECT ", $data);
        $data = str_ireplace([" from "], ' FROM ', $data);
        $data = str_ireplace([" where "], ' WHERE ', $data);
        $data = str_ireplace([" on "], ' ON ', $data);
        $data = str_ireplace([" as "], ' AS ', $data);
//var_dump($data);
        $joNo=substr_count(strtolower($data), strtolower('JOIN'));
        
        if (preg_match('/SELECT (.*?) FROM /', $data, $match) == 1){
        } 
        $data = str_ireplace([$match[0]], '', $data);
        //echo $joNo;
        $picJoin = explode('JOIN',$data);
        foreach($picJoin as $ind => $val)$picJoin[$ind]=trim($picJoin[$ind]);
        
        $where=$this->where($picJoin[$joNo]);
        if($where){
            $picJoin[$joNo]=$where[2];
            unset($where[2]);
        }
        $joTb[0]=explode(' ',$picJoin[0]);
        $colNm=[];

        for($i=1;$i<=$joNo;$i++){
            $slp=explode(' ON ',$picJoin[$i]);
            $joTb[$i]=explode(' ',$slp[0]);
            $relation=explode('=',$slp[1]);
            foreach($relation as $ind => $val)
                {$relation[$ind]=trim($relation[$ind]);}
            if(stripos($relation[0], $joTb[$i][1].".") !== false){
                $joTb[$i][2]=str_ireplace($joTb[$i][1].".", '', $relation[0]);
                $joTb[$i-1][2]=str_ireplace($joTb[$i-1][1].".", '', $relation[1]);
            }else{
                $joTb[$i][2]=str_ireplace($joTb[$i][1].".", '', $relation[1]);
                $joTb[$i-1][2]=str_ireplace($joTb[$i-1][1].".", '', $relation[0]);
            }
//var_dump($joTb);
            $key=array('tableInfo'=>$joTb[$i][0]);
            $tbif=$this->find_one($key);
            $tbif = json_decode(json_encode($tbif), true);
//var_dump($tbif['pk'],$joTb[$i][2]);
            if($tbif['pk']==$joTb[$i][2]){
                $pkTb=$joTb[$i][0];$pkTg=$joTb[$i][1];$pkVa=$joTb[$i][2];
                $fkTb=$joTb[$i-1][0];$fkTg=$joTb[$i-1][1];$fkVa=$joTb[$i-1][2];
            }else{
                $fkTb=$joTb[$i][0];$fkTg=$joTb[$i][1];$fkVa=$joTb[$i][2];
                $pkTb=$joTb[$i-1][0];$pkTg=$joTb[$i-1][1];$pkVa=$joTb[$i-1][2];
            }
            $key=array('tableInfo'=>$fkTb);
            $tbif=$this->find_one($key);
            $tbif = json_decode(json_encode($tbif), true);
            $fkPk=$tbif['pk'];

            $fKey=array('tableName'=>$fkTb);
            $frows=$this->all_query($fKey);
            $pKey=array('tableName'=>$pkTb);
            $prows=$this->all_query($pKey);
            $count=0;
            if(!isset($out)){
                $out=array('current_field' => 0,
                'field_count' => 0,
                'lengths' => null,
                'num_rows' => 0,
                'type' => 0);
                foreach($frows as $frow){
                    unset($newOld);
                    //$frow=$frow->toArray();
                    $frow=json_decode(json_encode($frow), true);
                    unset($frow['_id']);
                    unset($frow['tableName']);
                    foreach($prows as $prow){
                        $prow=json_decode(json_encode($prow), true);
                        unset($prow['_id']);
                        unset($prow['tableName']);
                        //$prow=$prow->toArray();
//var_dump($pkTg,$fkTg);
                        if($prow[$pkVa] == $frow[$fkVa]){
                            foreach($prow as $ind => $val) {$newOut[$pkTg.".".$ind]= $val;if(!in_array(($pkTg.".".$ind),$colNm))$colNm[]=$pkTg.".".$ind;}
                            foreach($frow as $ind => $val) {$newOut[$fkTg.".".$ind]= $val;if(!in_array(($fkTg.".".$ind),$colNm))$colNm[]=$fkTg.".".$ind;}
                            $count++;
                        }
                    }
                    if(isset($newOut))array_push($out, $newOut);
                }$out['num_rows']=$count;
                $out['field_count']=count($colNm);
// var_dump($out);
            }else{$add=0;
                $outRow=$out['num_rows'];
                foreach($frows as $frow){
                    $m=0;
                    $frow=json_decode(json_encode($frow), true);
                    unset($frow['_id']);
                    unset($frow['tableName']);
                    $count=0;
                    for($i=0; $i<$out['num_rows']; $i++){
                        if($out[$i][$fkTg.".".$fkPk]==$frow[$fkPk]){
                            $m++;
                            if(isset($out[$i][$fkTg.".".$fkVa])){
                                foreach($prows as $prow)
                                {   $prow=json_decode(json_encode($prow), true);
                                    unset($prow['_id']);
                                    unset($prow['tableName']);
                                    if($prow[$pkVa]==$out[$i][$fkTg.".".$fkVa])
                                    {
                                        foreach($prow as $ind => $val) {$out[$i][$pkTg.".".$ind]= $val;if(!in_array(($pkTg.".".$ind),$colNm))$colNm[]=$pkTg.".".$ind;}
                                    }
                                }
                            }
                        }
                        //$count++;
                    }if($m==0){
                        foreach($prows as $prow)
                        {   $prow=json_decode(json_encode($prow), true);
                            unset($prow['_id']);
                            unset($prow['tableName']);
                            if($prow[$pkVa]=$frow[$fkVa])
                            {   
                                foreach($prow as $ind => $val) {$out[$outRow][$pkTg.".".$ind]= $val;if(!in_array(($pkTg.".".$ind),$colNm))$colNm[]=$pkTg.".".$ind;}
                                foreach($frow as $ind => $val) {$out[$outRow][$fkTg.".".$ind]= $val;if(!in_array(($fkTg.".".$ind),$colNm))$colNm[]=$fkTg.".".$ind;}
                                $outRow++;
                            }
                        }
                    }
                }   
                $out['num_rows']=$outRow;
                $out['field_count']=count($colNm);
                //$out['columns']=$colNm;
            }        
        }
        for($i=0; $i<$out['num_rows']; $i++){
            foreach($colNm as $name){
                if(!isset($out[$i][$name]))$out[$i][$name]=NULL;
            }
        }
        $what=trim($match[1]);
        if($what!='*'){
            //$xxOut=[][];
            $what = explode(',',$what);
            foreach($what as $ind=>$val){
                $what[$ind]=trim($what[$ind]);
                if(stripos($what[$ind], ' AS ') !== false){
                    $xxOut[$ind] = explode(' AS ',$what[$ind]);
                    $collOut[$ind]=$xxOut[$ind][0];
                    $asOut[$collOut[$ind]]=$xxOut[$ind][1];
                }
            }
            //foreach($col)
            
            for($i=0; $i<$out['num_rows']; $i++){
                foreach($out[$i] as $ind=>$val){
                    if(!in_array($ind,$collOut))unset($out[$i][$ind]);
                    else{
                        $xt[$asOut[$ind]]=$val;
                    }
                }
                if(($where!=false)&&($out[$i][$where[0]]!=$where[1])){
                    unset($out[$i]);$outRow--;
                }else{
                    if(isset($xt)){ unset($out[$i]);$out[$i]=$xt;}
                }
            }
            //$out['columns']=$what;
        }else{
            for($i=0; $i<$out['num_rows']; $i++){
                if(($where!=false)&&($out[$i][$where[0]]!=$where[1]))
                {
                    unset($out[$i]);$outRow--;
                }
            }  
        }
        $out['num_rows']=$outRow;
        $object = new stdClass();
        foreach ($out as $key => $value)
        {
            $object->$key = $value;
        } 
        return $object;
    }
    function where($data){
        if(stripos($data, ' WHERE ')!== false){
            
            $slp=explode(' WHERE ',$data);
            $where=explode('=',$slp[1]);
            $where[0]=trim($where[0]);
            $where[1]=trim($where[1]);
            if($where[1][0]!="'"&&$where[1][0]!='"')$where[1]=intval($where[1]);
            else
            $where[1] = str_replace(["'",'"'], '', $where[1]);
            $where[2] = $slp[0];
            return $where;
        }else return false;
    }
}